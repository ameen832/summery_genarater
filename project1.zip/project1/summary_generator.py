from flask import Flask, request, jsonify
from youtube_transcript_api import YouTubeTranscriptApi
from transformers import pipeline
import re
import speech_recognition as sr
import subprocess
import os
from pytube import YouTube
from flask_cors import CORS
app = Flask(__name__)
CORS(app)  # This will allow CORS for all routes

@app.route('/', methods=['GET'])
def index():
    return 'hello'

@app.route('/get-summary', methods=['POST'])
def get_summary():
    youtube_url = request.args.get('id')
    range_value = request.json.get('rangeSize')
    
    try:
        video_id = extract_video_id(youtube_url)
        if not video_id:
            return jsonify(error='Invalid YouTube URL')

        transcript = fetch_transcript(video_id)
        if transcript:
            result = ' '.join([item['text'] for item in transcript])
        else:
            result = download_and_transcribe_audio(youtube_url)

        return summarize_text(result, range_value)
    except Exception as e:
        return jsonify(error="An error occurred: " + str(e))

def extract_video_id(youtube_url):
    if 'youtube.com/watch?v=' in youtube_url:
        return youtube_url.split('v=')[1].split('&')[0]
    elif 'youtu.be/' in youtube_url:
        return youtube_url.split('youtu.be/')[1]
    return None

def fetch_transcript(video_id):
    try:
        return YouTubeTranscriptApi.get_transcript(video_id, languages=["en-US", "en", "en-UK"])
    except:
        return None

def download_and_transcribe_audio(youtube_url):
    yt  =YouTube(youtube_url)
    yt.streams.filter(only_audio=True, file_extension='mp4').first().download(filename='ytaudio.mp4')
    
    convert_audio('ytaudio.mp4', 'ytaudio.wav')
    
    r = sr.Recognizer()
    with sr.AudioFile('ytaudio.wav') as source:
        audio_data = r.record(source)
        transcript = r.recognize_google(audio_data)
    
    # Clean up files
    os.remove('ytaudio.mp4')
    os.remove('ytaudio.wav')
    
    return transcript

def convert_audio(input_file, output_file):
    command = [
        'ffmpeg', '-i', input_file, '-acodec', 'pcm_s16le', '-ar', '16000', output_file
    ]
    subprocess.call(command, shell=True)

def summarize_text(text, range_value):
    summarizer = pipeline('summarization')
    tokens = len(text.split())
    max_len = (tokens * range_value) // 100
    num_iters = max(1, len(text) // 1000)

    summarized_text = []
    for i in range(num_iters):
        start = i * 1000
        end = (i + 1) * 1000
        chunk = text[start:end]
        summary = summarizer(chunk, max_length=int(max_len / num_iters), min_length=int(max_len / num_iters) - 20)
        summarized_text.append(summary[0]['summary_text'])
    
    final_summary = ' '.join(summarized_text)
    cleaned_summary = re.sub(r'[\[\]\'"]', '', final_summary)
    
    return jsonify(summary=cleaned_summary)

if __name__ == '__main__':
    app.run(debug=True)